Domain		No._of_Sentences	No._of_Tokens
Grammar	  	    1.3K		  8.5K
General             7.8K		  117K
Agriculture	    2K			  39.5K
Tourism-Parallel    4K			  52K

     

The annotation is funded by DeitY, Govt. of India. 

Each folder contains 2 folders.
1. Documents
2. Data

The dependency annotation follows Paninian Grammar Framework (Guidelines in Documents). The mapping of the dependency labels with the stanford dependency labels are also in the Documents. The annotation follows SSF (Shakti Standard Format), for further details related to SSF, refer the SSF_Guide. 	
